package SoundSystem;

/* Modifiers:
  - 1 3 5
// 4 - 1 3 4 (conferir)
// 9 - 1 3 5 9 (conferir)
// 4/7 - 1 3 4 7 (conferir)
// 4/9 - 1 3 4 9 (conferir)
// 7/9 - 1 3 7 9
// m - 1 b3 5
// m7 - 1 b3 5 7
// m4/7 - 1 b3 4 7 (conferir)
// m9 - 1 b3 5 9

 *
 * // º - 1 b3 b5 7
 * // m5-/7 -
 * // 5-/7 -
 * // 7+ - 1 3 5 #7
 * // 7 - 1 3 5 7
 */

import java.lang.Character;

public class Chord extends MajorScale {
    static final String modifiers[] = {"","º", "4", "7", "7+", "9", "4/7", "5-/7", "4/9", "7/9", "m", "m7", "m4/7", "m9", "m5-/7"};
    private static final String modifierFormula[] = {   "024",
                                                        "0b2b46",
                                                        "023",
                                                        "0246",
                                                        "024#6",
                                                        "0248",
                                                        "0236",
                                                        "02b4",
                                                        "0238",
                                                        "0268",
                                                        "0b24",
                                                        "0b246",
                                                        "0b236",
                                                        "0b248",
                                                        "0b2b4" };

    private String note="";
    private String modifier="";

    public Chord(String note, String modifier) {
        super(note);
        this.setChordNote(note);
        this.setChordModifier(modifier);
    }

    public void setChordModifier(String newModifier){
        this.modifier = "";
        for(int i=0; i<modifiers.length; i++){
            if(modifiers[i].equals(newModifier)) {
                this.modifier = newModifier;
                return;
            }
        }
    }

    public String getChordModifier() {
        return this.modifier;
    }

    public void setChordNote(String newNote) {
        this.setScaleNote(newNote);
        this.note = this.getScaleNote();
    }

    public String getChordNote() {
        return this.note;
    }
    
    public int[] getNotes(){
        int chordNotes[] = new int[4];
        int chordNote;
        int pos = 0;
        int var = 0;

        for(int i=0; i<chordNotes.length; i++)
            chordNotes[i] = Note.INVALID_NOTE;

        for(int i=0; i<modifiers.length; i++){
            if(modifiers[i].equals(this.modifier)){
                for(int j=0; j<modifierFormula[i].length(); j++){
                    chordNote = Character.getNumericValue(modifierFormula[i].charAt(j));
                    if(chordNote >= 0  &&  chordNote < 10){
                        if(chordNote >= scale.length)
                            chordNote -= scale.length;
                        
                        chordNotes[pos] = this.scale[chordNote] + var;

                        if(pos > 0  &&  chordNotes[pos-1] > chordNotes[pos])
                            chordNotes[pos] += Note.notes.length;

                        pos++;
                        var=0;
                    }
                    else if(modifierFormula[i].charAt(j) == 'b'){
                        var = -1;
                    }
                    else if(modifierFormula[i].charAt(j) == '#'){
                        var = 1;
                    }
                }
            }

        }

        return chordNotes;
    }

    public String toString(){
        return (String) this.note + this.modifier;
    }
}


