struct veiculo_dado
{
       int placa;
       int ano_fabric;
       int kilometragem;
       char modelo[10];
};
struct tipo_nodo
{
       veiculo_dado info;
       struct tipo_nodo* ant;
       struct tipo_nodo* prox;
};
typedef struct veiculo_dado tipodado;
typedef struct tipo_nodo nodo;

nodo* Inicializa(void);
// inicializa a lista duplamente encadeada vazia, retornando ponteiro pra lista vazia
nodo* Insere(nodo* ptlista, int pos, tipodado dados);
// inser��o em posi��o relativa da lista, retornando ponteiro para lista atualizada
nodo* Exclui(nodo* ptlista, int pos);
// exclus�o de posi��o relativa da lista, retornando ponteiro para lista atualizada
int Imprime(nodo* ptlista);
// imprime lista, retornando c�digo de sucesso ou insucesso
nodo* Destroi(nodo* ptlista);
// destroi lista, retornando ponteiro pra lista vazia
