// implementa��o da interface

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prototipo.h"



nodo* Inicializa(void)
{
    return NULL;    
}

nodo* Insere(nodo *ptlista, int pos, tipodado dados)
{
    nodo *ptaux, *ptaux2, *ptnovo;
    int conta=0;
    

    for(ptaux=ptlista;ptaux;ptaux=ptaux->prox)
        conta++;
    
    ptnovo = (nodo*) malloc(sizeof(nodo));
    ptnovo->info = dados;
    
    if(pos==1)
    /*inserir no in�cio*/
    {
        ptnovo->ant=NULL;
        ptnovo->prox=ptlista;
        if(ptlista)
            ptlista->ant=ptnovo;
        ptlista=ptnovo;
        return ptlista;
    }
    if(pos>conta+1 || pos<=0)
    {
       printf("\nposicao invalida!\n");
       return ptlista;
    }
    if(pos==conta+1)
    /*inserir no final de uma lista com pelo menos um elemento*/
        {
            ptaux = ptlista;
            while(ptaux->prox)
                ptaux=ptaux->prox;
            ptaux->prox=ptnovo;
            ptnovo->ant=ptaux;
            ptnovo->prox=NULL;
            return ptlista;
        }
        else
        /*inserir no meio*/
        {
            ptaux=ptlista;
            while(pos!=2)
            {
                ptaux=ptaux->prox; //posiciona ptaux numa posi��o anterior a onde ser� inserido novo n�
                pos--;
            }
            ptnovo->prox=ptaux->prox;
            ptaux->prox=ptnovo;            
            ptaux2 = ptnovo->prox;
            ptaux2->ant=ptnovo;       
            ptnovo->ant=ptaux;
            return ptlista;
        }
}
nodo* Exclui(nodo* ptlista, int pos)
{
    nodo *ptaux, *ptaux2;
    int conta=0;
    

    if(!ptlista)
    {
        printf("\nlista vazia!\n");
        return ptlista;
    }
    for(ptaux=ptlista;ptaux;ptaux=ptaux->prox)
        conta++;
    if(pos==1)
    /*excluir do inicio*/
    {
        ptaux=ptlista;
        ptlista=ptaux->prox;
        ptlista->ant=NULL;
        free(ptaux);
        return ptlista;
    }
    if(pos>conta || pos<=0)
    {
       printf("\nposicao invalida!\n");
       return ptlista;
    }
    if(pos==conta)
    /*excluir do final*/
        {
            ptaux=ptlista;
            while(pos!=2)
            {
                ptaux=ptaux->prox; //posiciona ptaux numa posi��o anterior a onde ser� excluido o n�
                pos--;
            }
            free(ptaux->prox);
            ptaux->prox = NULL;            
            return ptlista;
        }
        else
        /*excluir do meio*/
        {
            ptaux=ptlista;
            while(pos!=2)
            {
                ptaux=ptaux->prox; //posiciona ptaux numa posi��o anterior a onde ser� excluido o n�
                pos--;
            }
            ptaux->prox=ptaux->prox->prox;
            ptaux2 = ptaux->prox;
            free(ptaux2->ant);
            ptaux->prox->ant=ptaux;
            return ptlista;
        }
}

int Imprime(nodo *ptlista)
{
    nodo *ptaux;
     
    if(!ptlista)
    {
       printf("\nlista vazia!\n");
       return 1;
    }
    ptaux=ptlista;
    do{
            printf("\nmodelo: ");
            puts(ptaux->info.modelo);
            printf("placa: %4.d\n", ptaux->info.placa);
            printf("ano de fabricacao: %4.d\n", ptaux->info.ano_fabric);
            printf("kilometragem: %d\n", ptaux->info.kilometragem);
            ptaux=ptaux->prox;
        }while(ptaux);
    return 0;
}


nodo* Destroi(nodo* ptlista)
{
    nodo* ptaux;
    
    if(!ptlista)
    { 
        printf("\nlista vazia!\n");
        return ptlista;
    }
    ptaux=ptlista->prox;
    free(ptlista);
    do{
            ptaux=ptaux->prox;
            free(ptaux);
        }while(ptaux->prox);
    return NULL;
}
