#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prototipo.h"

int main()
{
    nodo *ptlista;
    tipodado dados;

    ptlista = Inicializa();
    strcpy(dados.modelo,"modelo");
    dados.placa = 1;
    dados.ano_fabric = 1990;
    dados.kilometragem= 9;
    ptlista = Insere(ptlista,1,dados);
    dados.placa = 2;
    ptlista = Insere(ptlista,2,dados);
    dados.placa = 3;
    ptlista = Insere(ptlista,2,dados);
    system("pause"); 
    Imprime(ptlista);
    ptlista = Destroi(ptlista);
    system("pause");

}
