/*
CRISTIANO MEDEIROS DALBEM
25 de setembro de 2008
Estruturas de Dados - UFRGS
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "abp.h"


int main()
{
    int scan, info;
    pNodoA a1=NULL, a2=NULL;
    
        printf("ARVORE 1\n\n");
    do{
        printf("inserir?(1/0) ");
        scanf("%i",&scan);
        if(scan)
        {
                printf("inserir int: ");
                scanf("%i",&info);
                a1 = InsereArvore(a1, info);
        }
        }while(scan);
        printf("ARVORE 2\n\n");
    do{
        printf("inserir?(1/0) ");
        scanf("%i",&scan);
        if(scan)
        {
                printf("inserir int: ");
                scanf("%i",&info);
                a2 = InsereArvore(a2, info);
        }
        }while(scan);
    
    imprimeABP(a1);
    printf("\n");
    imprimeABP(a2);
    printf("\n");    
    if(comparaABP(a1, a2))
        printf("\nArvores iguais\n\n");
        else
        printf("\nArvores diferentes\n\n");

    system("pause");  
     

}


