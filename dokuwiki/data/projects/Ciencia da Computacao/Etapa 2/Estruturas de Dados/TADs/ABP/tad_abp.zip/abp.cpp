/*
CRISTIANO MEDEIROS DALBEM
25 de setembro de 2008
Estruturas de Dados - UFRGS
*/

#include <stdio.h>
#include <stdlib.h>
#include "abp.h"

pNodoA InsereArvore(pNodoA a, int ch)
{
     if (a == NULL)
     {
         a =  (pNodoA) malloc(sizeof(TNodoA));
         a->info = ch;
         a->esq = NULL;
         a->dir = NULL;
     }
     else 
          if (ch < (a->info))
              a->esq = InsereArvore(a->esq,ch);
          else
              a->dir = InsereArvore(a->dir,ch);          
     return a;
}

void preFixado(pNodoA a)
{
     if (a!= NULL)
     {
          printf("%d\n",a->info);
          preFixado(a->esq);
          preFixado(a->dir);
     }
}

void Central(pNodoA a)
{
     if (a!= NULL)
     {
          Central(a->esq);
          printf("%d\n",a->info);
          Central(a->dir);
     }
}

void posFixado(pNodoA a)
{
     if (a!= NULL)
     {
          posFixado(a->esq);
          posFixado(a->dir);
          printf("%d\n",a->info);
      }
}

pNodoA consultaABP(pNodoA a, char chave) {
 
    while (a!=NULL){
          if (a->info == chave )
             return a; //achou ent�o retorna o ponteiro para o nodo
          else
            if (a->info > chave)
               a = a->esq;
            else
               a = a->dir;
            }
            return NULL; //se n�o achou
}

pNodoA consultaABP2(pNodoA a, char chave) {
    if (a==NULL)
       return NULL;
    else 
       if (a->info == chave)
          return a;
       else 
           if (a->info > chave)
               return consultaABP2(a->esq,chave);
            else
               return consultaABP2(a->dir,chave);
}

int comparaABP(pNodoA a1, pNodoA a2)
{
    if (a1==NULL && a2==NULL)
       return 1;
    else
        if (a1==NULL || a2==NULL)
           return 0;
           
    if(a1->info == a2->info)
       return (comparaABP(a1->esq,a2->esq) * comparaABP(a1->dir,a2->dir));
    else
       return 0;
}
pNodoA imprimeAUX(pNodoA a, int i)
{
     int k;
     if (a!= NULL)
     {
          i++;
          for(k=0;k<i;k++)
            printf("=");
          printf("%d\n",a->info);
          imprimeAUX(a->esq, i);
          imprimeAUX(a->dir, i);
     }
}
pNodoA imprimeABP(pNodoA a)
{
    imprimeAUX(a,0);
}
