/*
Cristiano Medeiros Dalbem
UFRGS - Estruturas de Dados - Turma C
9 de setembro de 2008
*/


#include <stdio.h>
#include <stdlib.h>
#include "Pilha.h"


int main ()
{  
    TipoPilha *P1, *P2;
    TipoInfo dado;
    
    P1=InicializaPilha(P1);
    P2=InicializaPilha(P2);
    
    printf("\n                 TESTE 1\n\n");
    P1 = PushPilha(P1,5);
    P1 = PushPilha(P1,7);
    P1 = PushPilha(P1,2);
    P1 = PushPilha(P1,6);
    ImprimirPilha(P1);
    P2 = PushPilha(P2,5);
    P2 = PushPilha(P2,7);
    P2 = PushPilha(P2,2);
    P2 = PushPilha(P2,6);
    ImprimirPilha(P2);

    if (ComparaPilha(&P1,&P2))
       printf("pilha 1 = pilha 2\n");
    else
       printf("pilha 1 eh diferente de pilha 2\n");
    ImprimirPilha(P1);
    ImprimirPilha(P2);
    
    
    P1=DestroiPilha(P1);
    P2=DestroiPilha(P2);
    printf("\n                 TESTE 2\n\n"); 
    P1 = PushPilha(P1,5);
    P1 = PushPilha(P1,7);
    P1 = PushPilha(P1,2);
    P1 = PushPilha(P1,6);
    ImprimirPilha(P1);
    P2 = PushPilha(P2,5);
    P2 = PushPilha(P2,7);
    P2 = PushPilha(P2,2);
    ImprimirPilha(P2);  

    if (ComparaPilha(&P1,&P2))
       printf("pilha 1 = pilha 2\n");
    else
       printf("pilha 1 eh diferente de pilha 2\n"); 
    ImprimirPilha(P1);
    ImprimirPilha(P2);
    
    
    P1=DestroiPilha(P1);
    P2=DestroiPilha(P2);
    printf("\n                 TESTE 3\n\n");
    ImprimirPilha(P1);
    P2 = PushPilha(P2,5);
    P2 = PushPilha(P2,7);
    P2 = PushPilha(P2,2);
    P2 = PushPilha(P2,6);    
    ImprimirPilha(P2);  
    
    if (ComparaPilha(&P1,&P2))
       printf("pilha 1 = pilha 2\n");
    else
       printf("pilha 1 eh diferente de pilha 2\n");
    ImprimirPilha(P1);
    ImprimirPilha(P2);

       
    P1=DestroiPilha(P1);
    P2=DestroiPilha(P2);
    printf("\n                 TESTE 4\n\n");
    P1 = PushPilha(P1,5);
    P1 = PushPilha(P1,7);
    P1 = PushPilha(P1,2);
    P1 = PushPilha(P1,6);
    ImprimirPilha(P1); 
    ImprimirPilha(P2);  
    
    if (ComparaPilha(&P1,&P2))
       printf("pilha 1 = pilha 2\n");
    else
       printf("pilha 1 eh diferente de pilha 2\n");
    ImprimirPilha(P1);
    ImprimirPilha(P2);       


    P1=DestroiPilha(P1);
    P2=DestroiPilha(P2);
    printf("\n                 TESTE 5\n\n");
    P1 = PushPilha(P1,5);
    P1 = PushPilha(P1,7);
    P1 = PushPilha(P1,2);
    P1 = PushPilha(P1,6);
    ImprimirPilha(P1); 
    ImprimirPilha(P2);  
    
    if (ComparaPilha(&P1,&P2))
       printf("pilha 1 = pilha 2\n");
    else
       printf("pilha 1 eh diferente de pilha 2\n");                   
    ImprimirPilha(P1);
    ImprimirPilha(P2);
    
    
   system("pause");
}
