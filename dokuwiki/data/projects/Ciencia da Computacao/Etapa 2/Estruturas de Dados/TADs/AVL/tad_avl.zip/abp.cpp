/*
Cristiano Medeiros Dalbem
UFRGS - Estruturas de Dados - Turma C
7 de outubro de 2008
*/

#include <stdio.h>
#include <stdlib.h>
#include "abp.h"

void Desenha(pNodoA a , int nivel)
{
int x;

 if (a !=NULL)
 {
   for (x=1; x<=nivel; x++)
      printf("=");
   printf("%d \n", a->info);
   if (a->esq != NULL) Desenha(a->esq, (nivel+1));
   if (a->dir != NULL) Desenha(a->dir, (nivel+1));
 }
}
pNodoA InsereArvore(pNodoA a, TipoInfo ch)
{
     if (a == NULL)
     {
         a =  (pNodoA) malloc(sizeof(TNodoA));
         a->info = ch;
         a->esq = NULL;
         a->dir = NULL;
     }
     else 
          if (ch < (a->info))
              a->esq = InsereArvore(a->esq,ch);
          else
              a->dir = InsereArvore(a->dir,ch);          
     return a;
}


int testaAVL (pNodoA a)
{
    int fator;
    if(a == NULL)
        return 1;

    fator = altura(a->esq) - altura(a->dir);
    if(fator<0)
        fator = fator * -1;

    if(fator>1)
        return 0;
    else
        return testaAVL(a->esq) * testaAVL(a->dir);

}

int alturaAux(pNodoA a, int h)
{
    pNodoA paux;
    int alt_e, alt_d;
    
    if (a == NULL)
        return h;

    alt_e = alturaAux(a->esq,h+1);
    alt_d = alturaAux(a->dir,h+1);
    
    if (alt_e > alt_d)
        return alt_e;
        else
            return alt_d;
}
int altura(pNodoA a)
{
    return alturaAux(a,0);
}
