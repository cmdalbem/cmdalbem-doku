/*
Cristiano Medeiros Dalbem
UFRGS - Estruturas de Dados - Turma C
7 de outubro de 2008
*/

typedef int TipoInfo;

struct TNodoA{
        TipoInfo info;
        struct TNodoA *esq;        
        struct TNodoA *dir;        
};

typedef struct TNodoA *pNodoA;

pNodoA InsereArvore(pNodoA a, TipoInfo ch);
void Desenha(pNodoA a , int nivel);
int testaAVL(pNodoA a);
int altura(pNodoA a);


