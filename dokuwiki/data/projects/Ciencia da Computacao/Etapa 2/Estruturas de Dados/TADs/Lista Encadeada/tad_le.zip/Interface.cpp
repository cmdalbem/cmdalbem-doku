#include <stdlib.h>
#include <stdio.h>
#include "Interface.h"

struct Produto
{
        int codigo;
        char nome[30];
        float preco;
        };
struct Nodo
{
        Produto info;
        Nodo* prox;
        };

                
Nodo* Inicializa_Lista(void)
{
      return NULL;
}

void Imprime(nodo* l)
{
     nodo* ptaux;
     if(l==NULL)
        printf("lista vazia\n");
        else
        for(ptaux=l;ptaux!=NULL;ptaux=ptaux->prox)
           printf("Codigo: %d; Nome: %s; Preco: R$%.2f",
                           ptaux->info.codigo,
                           ptaux->info.nome,
                           ptaux->info.preco);
}

void Insere_produto(nodo* l, nodo item)
{
     nodo* novo, ptaux;
     int inseriu=0;
     
     if(l==NULL) // lista vaiza
     {  
        novo = (nodo*) malloc(sizeof(nodo));
        *novo = item;
        *l = *novo;
     }
     else
     {
         for(ptaux=l; (ptaux!=NULL) || inseriu ;ptaux=ptaux->prox) // varre lista at� o final ou at� conseguir inserir o novo produto
            if(item->info.codigo < ptaux->prox->info.codigo) // analisa codigo do PROXIMO
            {
               novo = (nodo*) malloc(sizeof(nodo));
               *novo = item;
               novo->prox = ptaux->prox;
               ptaux->prox = novo;
               inseriu = 1;
               if(ptaux==l) //inseriu no inicio
                  *l = *novo;
            }
         printf("Insercao realizada com sucesso.\n");
     }      
}
