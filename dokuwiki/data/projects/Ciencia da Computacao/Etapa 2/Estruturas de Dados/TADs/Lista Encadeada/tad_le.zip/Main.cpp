/* 
Cristiano Medeiros Dalbem
TRABALHO N�O CONCLU�DO
A l�gica e a estrutura do programa creio estarem corretas, mas h� v�rias 
inconsist�ncias no tratamento de ponteiros que n�o fui capaz de resolver a tempo.
*/

#include <stdlib.h>
#include <stdio.h>
#include "interface.h"

int main()
{
     Nodo novoproduto;
     Nodo* l;
     int opcao;
     
     do{
         printf("1. Inicializar lista\n2. Imprimir lista\n3. Inserir produto\n4. Sair");
         scanf("%i",&opcao);
         switch(opcao)
         {
            case 1: *l = Inicializa_Lista();
                    break;
            case 2: Imprime(l);
                    break;
            case 3: 
                    printf("Codigo: ");
                    scanf("%i",novoproduto.info.codigo);
                    printf("Nome: ");
                    gets(novoproduto.info.nome);
                    printf("Preco: ");
                    scanf("%f",novoproduto.info.preco);
                    Insere_produto(l, novoproduto);
         }   
     }while(opcao==4)


    printf("\n\n");
    system("pause");
    return 0;
    
}
