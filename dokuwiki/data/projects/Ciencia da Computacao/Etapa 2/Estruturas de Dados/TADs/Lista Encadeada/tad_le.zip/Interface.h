typedef struct Produto produto;
typedef struct Nodo nodo;

// Inicializa lista
nodo* Inicializa_Lista(void);
// Imprime lista
void Imprime(nodo*);
// Insere produto em ordem crescente de c�digo
void Insere_produto(nodo*, nodo);
